import "./App.css";
import HomePage from "./Components/HomePage";
import "bootstrap/dist/css/bootstrap.min.css";
import FormComponent from "./Components/FormComponent";
import NavBar from "./Components/NavBar";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Welcome from "./Components/Welcome";
import { fetchItems } from "./redux";
import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { Button } from "react-bootstrap";
import ThemeContext, { themes } from "./ThemeContext";
import RecentlyAdded from "./Components/RecentlyAdded";

const App = ({ itemData, fetchItems }) => {
  useEffect(() => {
    console.log("Fetching API");
    fetchItems();
  }, []);

  const [theme, setTheme] = useState(themes.light);

  const toggleTheme = () => {
    theme === themes.dark ? setTheme(themes.light) : setTheme(themes.dark);
  };

  console.log("From APP ", itemData);

  return (
    <>
      <ThemeContext.Provider value={theme}>
        <BrowserRouter>
          {/* Always use link inside router */}

          {/*<HomePage />*/}

          {/*<FormComponent />*/}

          <NavBar />

          <br></br>

          <center>
            <Button variant="secondary" onClick={toggleTheme}>
              Switch Theme
            </Button>
          </center>
          <br></br>

          <Switch>
            <Route exact path="/" component={Welcome} />

            {/* <Route exact path="/home" component={HomePage}  /> */}

            <Route
              exact
              path="/home"
              render={props => <HomePage {...props} itemData={itemData} />}
            />

            <Route exact path="/form" component={FormComponent} />
            <Route exact path="/recent" component={RecentlyAdded} />
          </Switch>
        </BrowserRouter>
      </ThemeContext.Provider>
    </>
  );
};

const mapStateToProps = state => {
  return {
    itemData: state.home,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    fetchItems: () => dispatch(fetchItems()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(App);
