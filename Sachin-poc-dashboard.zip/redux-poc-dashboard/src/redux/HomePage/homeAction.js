import axios from "axios";

import {
  FETCH_ITEMS_REQUEST,
  FETCH_ITEMS_ERROR,
  FETCH_ITEMS_SUCCESS,
  ADD_PRODUCT,
} from "./homeType";

export const fetchItemsRequest = () => {
  return {
    type: FETCH_ITEMS_REQUEST,
  };
};

//remove all exports

const fetchItemsSuccess = items => {
  return {
    type: FETCH_ITEMS_SUCCESS,
    payload: items,
  };
};

const fetchItemsError = error => {
  return {
    type: FETCH_ITEMS_ERROR,
    payload: error,
  };
};

export const addProducts = product => {
  return {
    type: ADD_PRODUCT,
    payload: product,
  };
};

/*
export const submitProductDetails = product => {
  return dispatch => {
    console.log("submitProductDetails", product);
    dispatch(addProducts(product));
  };
};
*/
//thunk provides action creater the abilty to retun a function
//here we are fetching the API
export const fetchItems = () => {
  return dispatch => {
    dispatch(fetchItemsRequest);
    axios
      .get("https://fakestoreapi.com/products")
      .then(response => {
        const items = response.data;
        dispatch(fetchItemsSuccess(items));
      })
      .catch(error => {
        const errorMsg = error.message;
        dispatch(fetchItemsError(errorMsg));
      });
  };
};
