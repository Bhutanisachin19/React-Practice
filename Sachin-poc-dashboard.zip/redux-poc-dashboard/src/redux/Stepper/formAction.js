import { ADD_PRODUCT, ADD_ALL_PRODUCTS } from "./formType";

export const addProducts = product => {
  return {
    type: ADD_PRODUCT,
    payload: product,
  };
};

export const addAllProducts = () => {
  return {
    type: ADD_ALL_PRODUCTS,
  };
};

//pass product details from the form
export const submitProductDetails = product => {
  return dispatch => {
    console.log("submitProductDetails", product);
    dispatch(addProducts(product));
  };
};
