import { ADD_PRODUCT, ADD_ALL_PRODUCTS } from "./formType";

const initialState = {
  title: "",
  category: "",
  price: "",
  description: "",
  image: "",
  all: [],
};

const formReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_PRODUCT:
      return {
        ...state,
        title: action.payload.title,
        category: action.payload.category,
        price: action.payload.price,
        description: action.payload.description,

        all: [...state.all, action.payload],
      };

    
    case ADD_ALL_PRODUCTS:
      console.log("ADD ALL PRODUCTS", state);
      return {
        
      };

    default:
      return state;
  }
};

export default formReducer;
