// to display recently added products

// to display all items

import React, { useEffect, useContext } from "react";
import { connect } from "react-redux";
import { fetchItems } from "../redux";
import { Button, Card } from "react-bootstrap";
import ThemeContext from "../ThemeContext";

const RecentlyAdded = ({ itemData }) => {
  const theme = useContext(ThemeContext);

  /*
  useEffect(() => {
    console.log("Fetching API");
    fetchItems();
  }, []);
  // is being displayed one in a row ########################################################
  //how to display 3-4 items in a row?????
  const itemList = itemData.items.map(item => (
    <div key={item.id}>
    
      <Card style={{ width: "18rem" }}>
        <Card.Img variant="top" src={item.image} />
        <Card.Body>
          <Card.Title>{item.title}</Card.Title>
          <Card.Text>{item.category}</Card.Text>
          <Card.Text>{item.description}</Card.Text>
          <Card.Text>{item.price}</Card.Text>

          <Button variant="info">Buy Product</Button>
        </Card.Body>
      </Card>
    </div>
  ));
  */
  {
    console.log(itemData.all);
  }
  return (
    <center>
      {itemData.all.length > 0 ? (
        <div style={theme} className="row">
          <br></br>
          {itemData.all.map(item => (
            <div key={item.id} className="p-5 col-md-3">
              <h3>Added by : {item.vendorName}</h3>
              <Card style={({ width: "18rem" }, theme)}>
                <Card.Img variant="top" src={item.image} />
                <Card.Body>
                  <Card.Title>{item.title}</Card.Title>
                  <Card.Text>{item.category}</Card.Text>
                  <Card.Text>{item.description}</Card.Text>
                  <Card.Text>{item.price}</Card.Text>
                  <Button variant="info">Buy Product</Button>
                </Card.Body>
              </Card>
            </div>
          ))}
        </div>
      ) : (
        <h2 style={theme}>No Product Has Been Added yet </h2>
      )}
      <br></br>
    </center>
  );
};

const mapStateToProps = state => {
  return {
    itemData: state.form,
  };
};

/*
const mapDispatchToProps = dispatch => {
  return {
    fetchAllProducts: () => dispatch(fetchAllProducts()),
  };
};
*/

export default connect(mapStateToProps, null)(RecentlyAdded);
