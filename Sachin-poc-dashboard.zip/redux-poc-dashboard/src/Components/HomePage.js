// to display all items

import React, { useEffect, useContext } from "react";
import { connect } from "react-redux";
import { fetchItems } from "../redux";
import { Button, Card } from "react-bootstrap";
import ThemeContext from "../ThemeContext";

const HomePage = ({ itemData }) => {
  const theme = useContext(ThemeContext);

  /*
  useEffect(() => {
    console.log("Fetching API");
    fetchItems();
  }, []);
  // is being displayed one in a row ########################################################
  //how to display 3-4 items in a row?????
  const itemList = itemData.items.map(item => (
    <div key={item.id}>
    
      <Card style={{ width: "18rem" }}>
        <Card.Img variant="top" src={item.image} />
        <Card.Body>
          <Card.Title>{item.title}</Card.Title>
          <Card.Text>{item.category}</Card.Text>
          <Card.Text>{item.description}</Card.Text>
          <Card.Text>{item.price}</Card.Text>

          <Button variant="info">Buy Product</Button>
        </Card.Body>
      </Card>
    </div>
  ));
  */

  return itemData.loading ? (
    <h2>Loading...</h2>
  ) : itemData.error ? (
    <h2>itemData.error</h2>
  ) : (
    <div>
      <br></br>
      <br></br>
      <center>
        <h1 className="Shop">Welcome To The Store</h1>
      </center>

      <div className="row" style={theme}>
        {itemData &&
          itemData.items &&
          itemData.items.map(item => (
            <div key={item.id} className="p-5 col-md-3">
              {/*<p>{item.title}</p>*/}
              <Card style={({ width: "18rem" }, theme)}>
                <Card.Img variant="top" src={item.image} />
                <Card.Body>
                  <Card.Title>{item.title}</Card.Title>
                  <Card.Text>{item.category}</Card.Text>
                  <Card.Text>{item.description}</Card.Text>
                  <Card.Text>{item.price}</Card.Text>
                  <Button variant="info">Buy Product</Button>
                </Card.Body>
              </Card>
            </div>
          ))}
      </div>
    </div>
  );
};

/*
const mapStateToProps = state => {
  return {
    itemData: state.home,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    fetchItems: () => dispatch(fetchItems()),
  };
};
*/

export default HomePage;
