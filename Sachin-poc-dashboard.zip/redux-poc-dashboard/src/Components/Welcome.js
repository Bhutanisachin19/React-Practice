import React, { useContext } from "react";
import ThemeContext from "../ThemeContext";
import Barca_logo from "../Barcelona_Logo.png";

const Welcome = () => {
  const theme = useContext(ThemeContext);

  return (
    <div style={theme}>
      <br></br>
      <center>
        <h1>Welcome to my Store</h1>
        <img src={Barca_logo} alt="Logo" height="500" />
      </center>
    </div>
  );
};

export default Welcome;
