import React, { useState, useEffect, useContext } from "react";
import { Form, Button } from "react-bootstrap";
import { useDispatch } from "react-redux";
import "bootstrap/dist/css/bootstrap.min.css";
import "./FormComponent.css";

import {
  addAllProducts,
  submitProductDetails,
} from "../redux/Stepper/formAction";
import { connect } from "react-redux";
import { addProducts } from "../redux/HomePage/homeAction";

import barca from "../redux/HomePage/barcaa.png";
import ThemeContext from "../ThemeContext";

import { Redirect } from "react-router-dom";

const FormComponent = ({ itemData, submitProductDetails }) => {
  /*
  const [product, setProduct] = useState({
    title: "",
    category: "",
    price: "",
    description: "",
  });
  */

  const theme = useContext(ThemeContext);

  const dispatch = useDispatch();
  const [vendorName, setVendorName] = useState("");

  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");

  //const [image, setImage] = useState(barca); //static image

  const [image, setImage] = useState(barca); //static image

  const [getaRedirect, setGetATedirect] = useState(false);

  //counter
  const [count, setCount] = useState(1);

  const handleTitle = event => {
    setTitle(event.target.value);
    console.log(title);
  };
  const handlePrice = event => {
    setPrice(event.target.value);
    console.log("handlePrice", price);
  };

  const handleVendor = event => {
    setVendorName(event.target.value);
    console.log("Vendor Name", vendorName);
  };

  const handleCategory = event => {
    setCategory(event.target.value);
    console.log("handleCAtegory", category);
  };

  const handleDescription = event => {
    setDescription(event.target.value);
    console.log("handleDescription", description);
  };

  const handleImage = event => {
    setImage(event.target.files[0].name);
    console.log("handleImage");
  };

  const perfomRedirect = () => {
    if (getaRedirect) {
      return <Redirect to="/home" />;
    }
  };

  const handleSubmit = event => {
    event.preventDefault();

    /*
    console.log("ITEM DATA ", itemData);
    console.log("Form will not be submitted");
    console.log("Title is ", title);
    console.log("Price is ", price);
    console.log("Description is", description);
    console.log("Category is ", category);
    */

    if (
      title === "" ||
      price === "" ||
      category == "" ||
      description == "" ||
      vendorName === ""
    ) {
      alert("Please enter all the fields to move forward");
    } else {
      const product = {
        title,
        price,
        category,
        description,
        image,
        vendorName,
      };

      console.log("Product is ", product);

      // dispatch is send to all the reducers , hence the form and home both reducer actions are called and executed
      // this is why one action is updating in both the reducers i.e form and home
      dispatch(addProducts(product));

      // dispatch(addAllProducts(product));

      setCount(count + 1);

      // to redirect the page after 4 seconds
      setTimeout(() => {
        setGetATedirect(true);
      }, 4000);
    }
  };

  return (
    <center>
      <div className="FormComp" style={theme}>
        <br></br>
        <br></br>

        {count < 5 ? (
          <div style={theme}>
            <h2>Enter the details of the form </h2>

            <h2>Step {count} of 4 </h2>

            <br></br>
            <br></br>

            <Form>
              {count === 1 ? (
                <Form.Group controlId="formVendor">
                  <Form.Label>
                    <b>Enter Vendor Name</b>
                  </Form.Label>
                  <Form.Control
                    type="text"
                    value={vendorName}
                    onChange={handleVendor}
                    placeholder="Enter the Name of the Vendor"
                  />
                </Form.Group>
              ) : null}

              {count === 2 ? (
                <div>
                  <Form.Group controlId="formTitle">
                    <Form.Label>
                      <b>Title</b>
                    </Form.Label>
                    <Form.Control
                      type="text"
                      value={title}
                      onChange={handleTitle}
                      placeholder="Enter title"
                    />
                  </Form.Group>

                  <Form.Group controlId="formCategory">
                    <Form.Label>
                      <b>Category</b>
                    </Form.Label>
                    <Form.Control
                      type="text"
                      value={category}
                      onChange={handleCategory}
                      placeholder="Enter the Category of Products"
                    />
                  </Form.Group>
                </div>
              ) : null}

              {count === 3 ? (
                <div style={theme}>
                  <Form.Group controlId="formPrice">
                    <Form.Label>
                      <b> Price </b>
                    </Form.Label>
                    <Form.Control
                      type="number"
                      value={price}
                      onChange={handlePrice}
                      placeholder="Enter the Price of Products"
                    />
                  </Form.Group>
                  <p>
                    The image you'll upload should be in <b> public </b> folder{" "}
                  </p>

                  <Form.Group controlId="formImage">
                    <Form.Label>
                      <b> Image </b>
                    </Form.Label>
                    <Form.Control
                      type="file"
                      // console.log(e.target.files[0].name)
                      onChange={handleImage}
                      placeholder="Upload an image of the product"
                    />
                  </Form.Group>

                  <Form.Group controlId="formPrice">
                    <Form.Label>
                      <b>Description</b>
                    </Form.Label>
                    <Form.Control
                      type="text"
                      value={description}
                      onChange={handleDescription}
                      placeholder="Enter the Description of Products"
                    />
                  </Form.Group>
                </div>
              ) : null}

              {count === 4 ? (
                <div style={theme}>
                  <h2>Product Details are</h2>
                  <p>
                    <b>Product Title is : </b>
                    {title}{" "}
                  </p>
                  <p>
                    {" "}
                    <b>Product Price is : </b>
                    {price}{" "}
                  </p>
                  <p>
                    {" "}
                    <b>Product Category is : </b>
                    {category}{" "}
                  </p>
                  <p>
                    {" "}
                    <b>Product Description is : </b>
                    {description}{" "}
                  </p>
                  <p>
                    {" "}
                    <b>Vendor Name is : </b>
                    {vendorName}{" "}
                  </p>
                </div>
              ) : null}

              {/*onClick={handleSubmit}*/}

              {count === 4 ? (
                <div style={theme}>
                  <Button
                    variant="primary"
                    type="submit"
                    onClick={handleSubmit}
                  >
                    Confirm
                  </Button>
                </div>
              ) : null}
            </Form>

            <br></br>

            <Button
              variant="success"
              type="submit"
              onClick={() => setCount(count - 1)}
              disabled={count < 2}
            >
              Back
            </Button>

            <Button
              variant="info"
              type="submit"
              onClick={() => setCount(count + 1)}
              disabled={count > 3}
            >
              Next
            </Button>
          </div>
        ) : (
          <div className="Info-div" style={theme}>
            <h3>
              Your product has been successfully added to the Shop , you will be
              redirected to the shop shortly (after 4 seconds)
              <b>Thank you {vendorName} </b>
            </h3>
            {perfomRedirect()}
          </div>
        )}
      </div>
    </center>
  );
};

const mapStateToProps = state => {
  return {
    itemData: state.form,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    submitProductDetails: product => dispatch(submitProductDetails(product)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(FormComponent);
